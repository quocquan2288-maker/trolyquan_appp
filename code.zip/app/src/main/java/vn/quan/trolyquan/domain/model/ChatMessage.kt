package vn.quan.trolyquan.domain.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class MessageSender {
    USER,
    QUAN,
    SYSTEM
}

/**
 * Đại diện cho một tin nhắn trong lịch sử hội thoại giữa người dùng và Quân.
 */
data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val moodTag: String = "THANG_THAN",
    val command: SystemCommand? = null,
    val executionResult: ActionExecutionResult? = null,
    val timestampMillis: Long = System.currentTimeMillis()
) {
    fun formattedTime(): String {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        return sdf.format(Date(timestampMillis))
    }

    fun moodBadgeLabel(): String = when (moodTag.uppercase(Locale.ROOT)) {
        "CA_KHIA" -> "Cà khịa"
        "NONG_TINH" -> "Nóng tính"
        "NHIET_TINH" -> "Nhiệt tình"
        "NGHIEM_TUC" -> "Chuẩn chỉ"
        else -> "Thẳng thắn"
    }
}
