package vn.quan.trolyquan

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import vn.quan.trolyquan.data.ai.LocalCommandFallbackParser
import vn.quan.trolyquan.domain.model.CommandType

class LocalCommandFallbackParserTest {

    @Test
    fun testOpenTikTokCommand() {
        val res = LocalCommandFallbackParser.parseUserText("Mở TikTok lên cho tôi")
        assertTrue(res.isConfidentSystemCommand)
        assertEquals(CommandType.OPEN_APP, res.command.type)
        assertEquals("tiktok", res.command.target)
    }

    @Test
    fun testOpenYouTubeCommand() {
        val res = LocalCommandFallbackParser.parseUserText("Mở YouTube")
        assertTrue(res.isConfidentSystemCommand)
        assertEquals(CommandType.OPEN_APP, res.command.type)
        assertEquals("youtube", res.command.target)
    }

    @Test
    fun testTorchOnAndOff() {
        val onRes = LocalCommandFallbackParser.parseUserText("Bật đèn pin")
        assertTrue(onRes.isConfidentSystemCommand)
        assertEquals(CommandType.TORCH_CONTROL, onRes.command.type)
        assertEquals(true, onRes.command.booleanValue)

        val offRes = LocalCommandFallbackParser.parseUserText("Tắt đèn pin đi")
        assertTrue(offRes.isConfidentSystemCommand)
        assertEquals(CommandType.TORCH_CONTROL, offRes.command.type)
        assertEquals(false, offRes.command.booleanValue)
    }

    @Test
    fun testVolumeCommands() {
        val upRes = LocalCommandFallbackParser.parseUserText("Tăng âm lượng")
        assertTrue(upRes.isConfidentSystemCommand)
        assertEquals(CommandType.VOLUME_CONTROL, upRes.command.type)
        assertEquals("UP", upRes.command.target)

        val setRes = LocalCommandFallbackParser.parseUserText("Đặt âm lượng 75%")
        assertTrue(setRes.isConfidentSystemCommand)
        assertEquals(CommandType.VOLUME_CONTROL, setRes.command.type)
        assertEquals("SET", setRes.command.target)
        assertEquals(75, setRes.command.intValue)
    }

    @Test
    fun testSensitiveCallRequiresConfirmation() {
        val callRes = LocalCommandFallbackParser.parseUserText("Gọi 0912345678")
        assertTrue(callRes.isConfidentSystemCommand)
        assertEquals(CommandType.CALL_NUMBER, callRes.command.type)
        assertEquals("0912345678", callRes.command.stringValue)
        assertTrue(callRes.command.requiresConfirmation)
    }
}
